using System;

namespace C__implementation
{
    public class GoodParticleEffect : ParticleEffect  {
        public void spawn() {
            Console.WriteLine("Good timing!");
        }
    };
}