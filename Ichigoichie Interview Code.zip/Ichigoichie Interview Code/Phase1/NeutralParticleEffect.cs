using System;

namespace C__implementation
{
    public class NeutralParticleEffect : ParticleEffect  {
        public void spawn() {
            Console.WriteLine("Loop switched.");
        }
    };
}